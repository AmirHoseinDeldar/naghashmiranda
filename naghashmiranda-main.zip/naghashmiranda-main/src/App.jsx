function App() {
  return (
    <>
      <h1>salam salam</h1>
    </>
  );
}

export default App;
